package org.kuali.coeus.award.finance;

import org.kuali.kra.award.home.Award;

public interface AccountService {

    public AccountInformationDto createAccountInformation(Award award);
}
